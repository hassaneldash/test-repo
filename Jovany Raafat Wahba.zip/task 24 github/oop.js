// 1
(function(a, b) {
  alert(a + b);
})(5, 3); 






// 2 

const numbers = [1, 2, 3, 4, 5, 6];

// odd num
const oddNumbers = numbers.filter(num => num % 2 !== 0);
console.log("Odd Numbers:", oddNumbers);

// even num 
console.log("Even Numbers:");
numbers.forEach(num => {
  if (num % 2 === 0) {
    console.log(num);
  }
});

// Map to squares
const squares = numbers.map(num => num * num);
console.log("Squares:", squares);



function testScope() {

  const demoObj = {
    name: "Jovany",

    arrowFunc: () => {
      console.log("Arrow Function 'this.name':", this.name); // comes from testScope's this
    },

    normalFunc: function () {
      console.log("Normal Function 'this.name':", this.name);
    }
  };

  demoObj.arrowFunc();
  demoObj.normalFunc();
}

testScope();











// 3

var arr1 = [1,2,4];
var arr2 = [5,6,7];
var arr3 = [...arr1, ...arr2]
console.log(arr3);






// 4 

// Define the Student class
class Student {
  constructor(name, university, faculty, finalGrade) {
    this.name = name;
    this.university = university;
    this.faculty = faculty;
    this.finalGrade = finalGrade;
  }

  // Method to print student info
  printInfo() {
    console.log(`${this.name} is a student in faculty of ${this.faculty} in university ${this.university}
And his final grade is ${this.finalGrade}.`);
  }
}

// Create a student object
const student1 = new Student("Ahmed", "Cairo University", "Engineering", "A");

// Call the method to print info
student1.printInfo();




